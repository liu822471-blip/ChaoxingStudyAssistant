package com.example.chaoxingassistant

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.*
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var urlBox: EditText
    private lateinit var output: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var wasEnded = false

    private val videoMonitor = object : Runnable {
        override fun run() {
            if (::web.isInitialized) {
                web.evaluateJavascript("""(function(){
                    const vs=[...document.querySelectorAll('video')];
                    if(!vs.length)return JSON.stringify({found:false});
                    const v=vs.find(x=>x.offsetWidth>0&&x.offsetHeight>0)||vs[0];
                    return JSON.stringify({found:true,ended:!!v.ended,paused:!!v.paused,
                    current:Number(v.currentTime||0),duration:Number.isFinite(v.duration)?v.duration:0});
                })();""") { raw ->
                    val s = raw?.replace("\\\"", "\"")?.trim('"') ?: ""
                    when {
                        s.contains("\"ended\":true") -> {
                            if (!wasEnded) status.text = "检测到视频自然播放结束；请核对学习通是否已记录完成。"
                            wasEnded = true
                        }
                        s.contains("\"found\":false") -> {
                            status.text = "未检测到可访问的视频；播放器可能位于跨域 iframe。"
                            wasEnded = false
                        }
                        s.contains("\"ended\":false") -> {
                            status.text = "视频监测中：等待自然播放结束。"
                            wasEnded = false
                        }
                    }
                }
            }
            handler.postDelayed(this, 1800)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CookieManager.getInstance().setAcceptCookie(true)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 6)
            setBackgroundColor(Color.WHITE)
        }
        page.addView(TextView(this).apply {
            text = "学习通学习助手 · v0.2"
            textSize = 20f
            setTextColor(Color.rgb(30, 55, 85))
            gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(-1, 44))

        urlBox = EditText(this).apply {
            setSingleLine(true)
            setText("https://mooc1.chaoxing.com/")
            hint = "学习通网址"
        }
        page.addView(urlBox, LinearLayout.LayoutParams(-1, 46))

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(Button(this).apply {
            text = "打开网页"
            setOnClickListener { openPage() }
        }, LinearLayout.LayoutParams(0, 44, 1f))
        buttons.addView(Button(this).apply {
            text = "返回"
            setOnClickListener { if (web.canGoBack()) web.goBack() }
        }, LinearLayout.LayoutParams(0, 44, 1f))
        buttons.addView(Button(this).apply {
            text = "识别本页"
            setOnClickListener { inspectPage() }
        }, LinearLayout.LayoutParams(0, 44, 1f))
        page.addView(buttons)

        status = TextView(this).apply {
            text = "请正常登录学习通。视频须完整播放；本原型提供页面识别与学习辅助。"
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(3, 6, 3, 6)
        }
        page.addView(status)

        output = TextView(this).apply {
            text = "点击“识别本页”查看页面结构线索。"
            textSize = 12f
            setTextColor(Color.rgb(45, 55, 70))
            setPadding(7, 7, 7, 7)
        }
        page.addView(ScrollView(this).apply { addView(output) },
            LinearLayout.LayoutParams(-1, 112))

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val target = request.url
                    val scheme = target.scheme?.lowercase() ?: ""
                    // Keep traffic encrypted: upgrade top-level HTTP navigations to HTTPS
                    // instead of enabling cleartext traffic for the whole app.
                    if (scheme == "http") {
                        val secureUrl = target.buildUpon().scheme("https").build()
                        view.loadUrl(secureUrl.toString())
                        status.text = "已将网页跳转升级为 HTTPS 安全连接。"
                        return true
                    }
                    return scheme != "https"
                }
                override fun onReceivedError(
                    view: WebView,
                    request: WebResourceRequest,
                    error: WebResourceError
                ) {
                    if (request.isForMainFrame) {
                        status.text = "网页加载失败：${error.description}（${request.url}）"
                    }
                }
                override fun onPageFinished(view: WebView, url: String) {
                    wasEnded = false
                    status.text = "页面已加载，请确认课程和章节信息。"
                }
            }
        }
        page.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
        web.loadUrl("https://mooc1.chaoxing.com/")
        handler.post(videoMonitor)
    }

    private fun openPage() {
        val raw = urlBox.text.toString().trim()
        val url = if (raw.startsWith("https://")) raw else "https://$raw"
        if (!url.startsWith("https://")) {
            status.text = "仅允许 HTTPS 页面。"
            return
        }
        web.loadUrl(url)
    }

    private fun inspectPage() {
        val script = """(function(){
          const clean=s=>(s||'').replace(/\s+/g,' ').trim();
          const lines=(document.body?document.body.innerText:'').split('\n').map(clean).filter(Boolean);
          const chapters=lines.filter(x=>/^\d+(\.\d+)?\s+/.test(x)).slice(0,90);
          const types=lines.filter(x=>/单选题|多选题|判断题|章节测验/.test(x)).slice(0,30);
          const qs=lines.filter(x=>/^\d+\s*[［\[【]?(单选题|多选题|判断题)/.test(x)).slice(0,50);
          return JSON.stringify({title:document.title,chapters:chapters,types:types,questions:qs,
            videoCount:document.querySelectorAll('video').length,hasSubmit:/提交/.test(lines.join(' '))});
        })();"""
        web.evaluateJavascript(script) { raw ->
            val decoded = raw?.replace("\\\"", "\"")?.trim('"') ?: ""
            try {
                val obj = JSONObject(decoded)
                fun section(label: String, arr: JSONArray): String {
                    val b = StringBuilder("$label\n")
                    for (i in 0 until arr.length()) b.append("• ").append(arr.optString(i)).append("\n")
                    return b.toString()
                }
                output.text = "页面：${obj.optString("title")}\n视频元素：${obj.optInt("videoCount")}\n\n" +
                    section("章节线索：", obj.optJSONArray("chapters") ?: JSONArray()) + "\n" +
                    section("题型线索：", obj.optJSONArray("types") ?: JSONArray()) + "\n" +
                    section("题目线索：", obj.optJSONArray("questions") ?: JSONArray()) +
                    "\n提示：用于学习和复习；请自行完成课程测验。"
                status.text = "页面识别完成。动态组件或 iframe 中的内容可能无法提取。"
            } catch (e: Exception) {
                output.text = "暂时无法解析页面结构，请稍后重试或滚动页面后再识别。"
                status.text = "页面识别未成功。"
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::web.isInitialized) {
            web.stopLoading()
            web.destroy()
        }
        super.onDestroy()
    }
}
