# 学习通学习助手 Android 原型 v0.2

## 本版功能
- Android WebView，默认打开 https://mooc1.chaoxing.com/
- 正常网页登录与 Cookie 会话保持
- 监测当前页面可访问的 HTML5 视频是否自然播放结束
- “识别本页”提取页面标题、章节目录文本线索、题型线索（单选/多选/判断）及题目文本线索
- 对跨域 iframe、专有播放器无法访问时给出提示

## 暂不实现
- 自动选择答案、自动提交计分测验/考试
- 伪造观看进度、跳过视频或绕过平台限制
- 未经验证的自动章节跳转

## 构建
使用 Android Studio 打开本目录，安装 Android SDK 35，等待 Gradle Sync 后连接 Android 设备并点击 Run。

这是源码项目，不是已签名 APK。项目不包含账号密码。
