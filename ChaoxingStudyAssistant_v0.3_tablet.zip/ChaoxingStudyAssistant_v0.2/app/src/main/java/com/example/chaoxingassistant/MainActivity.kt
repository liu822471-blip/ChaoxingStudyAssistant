package com.example.chaoxingassistant

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var urlBox: EditText
    private lateinit var output: TextView
    private lateinit var desktopButton: Button
    private lateinit var panel: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private var wasEnded = false
    private var desktopMode = true

    private val videoMonitor = object : Runnable {
        override fun run() {
            if (::web.isInitialized) {
                web.evaluateJavascript("""(function(){
                    const vs=[...document.querySelectorAll('video')];
                    if(!vs.length)return JSON.stringify({found:false});
                    const v=vs.find(x=>x.offsetWidth>0&&x.offsetHeight>0)||vs[0];
                    return JSON.stringify({found:true,ended:!!v.ended,paused:!!v.paused,
                    current:Number(v.currentTime||0),duration:Number.isFinite(v.duration)?v.duration:0});
                })();""") { raw ->
                    val s = raw?.replace("\\\"", "\"")?.trim('"') ?: ""
                    when {
                        s.contains("\"ended\":true") -> {
                            if (!wasEnded) status.text = "检测到视频自然播放结束；请核对学习通是否已记录完成。"
                            wasEnded = true
                        }
                        s.contains("\"found\":false") -> {
                            status.text = "未检测到可访问的视频；播放器可能位于跨域 iframe。"
                            wasEnded = false
                        }
                        s.contains("\"ended\":false") -> {
                            status.text = "视频监测中：仅记录当前页面可访问的视频状态。"
                            wasEnded = false
                        }
                    }
                }
            }
            handler.postDelayed(this, 1800)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        CookieManager.getInstance().setAcceptCookie(true)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 5, 10, 5)
            setBackgroundColor(Color.WHITE)
        }
        page.addView(TextView(this).apply {
            text = "学习通学习助手 · 平板版 0.3"
            textSize = 19f
            setTextColor(Color.rgb(30, 55, 85))
            gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(-1, 38))

        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        urlBox = EditText(this).apply {
            setSingleLine(true)
            setText("https://mooc1.chaoxing.com/")
            hint = "学习通网址"
            textSize = 14f
        }
        panel.addView(urlBox, LinearLayout.LayoutParams(-1, 42))

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun addAction(label: String, action: () -> Unit): Button {
            return Button(this).apply {
                text = label
                textSize = 12f
                setOnClickListener { action() }
            }.also { buttons.addView(it, LinearLayout.LayoutParams(0, 42, 1f)) }
        }
        addAction("打开网页") { openPage() }
        addAction("返回") { if (web.canGoBack()) web.goBack() }
        addAction("识别本页") { inspectPage() }
        desktopButton = addAction("电脑版：开") { toggleDesktopMode() }
        page.addView(buttons)

        status = TextView(this).apply {
            text = "已启用桌面网页模式。请正常登录学习通；视频须完整播放。"
            textSize = 11f
            setTextColor(Color.DKGRAY)
            setPadding(3, 3, 3, 3)
        }
        panel.addView(status)
        output = TextView(this).apply {
            text = "点击“识别本页”查看章节和题型线索。"
            textSize = 11f
            setTextColor(Color.rgb(45, 55, 70))
            setPadding(6, 4, 6, 4)
        }
        panel.addView(ScrollView(this).apply { addView(output) },
            LinearLayout.LayoutParams(-1, 76))
        page.addView(panel)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            applyUserAgent()
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val target = request.url
                    val scheme = target.scheme?.lowercase() ?: ""
                    if (scheme == "http") {
                        val secureUrl = target.buildUpon().scheme("https").build()
                        view.loadUrl(secureUrl.toString())
                        status.text = "已尝试使用 HTTPS 安全连接打开网页。"
                        return true
                    }
                    return scheme != "https"
                }
                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                    if (request.isForMainFrame) status.text = "网页加载失败：${error.description}（${request.url}）"
                }
                override fun onPageFinished(view: WebView, url: String) {
                    wasEnded = false
                    status.text = if (desktopMode) "电脑版页面已加载；若页面仍显示手机版，可尝试刷新或切换模式。" else "页面已加载，请确认课程和章节信息。"
                    view.evaluateJavascript("document.documentElement.style.minWidth='980px';", null)
                }
            }
        }
        page.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
        web.loadUrl("https://mooc1.chaoxing.com/")
        handler.post(videoMonitor)
    }

    private fun applyUserAgent() {
        val defaultUa = WebSettings.getDefaultUserAgent(this)
        if (desktopMode) {
            val chrome = Regex("Chrome/([0-9.]+)").find(defaultUa)?.groupValues?.get(1) ?: "120.0.0.0"
            web.settings.userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$chrome Safari/537.36"
            web.settings.useWideViewPort = true
            web.settings.loadWithOverviewMode = true
        } else {
            web.settings.userAgentString = defaultUa
            web.settings.useWideViewPort = false
            web.settings.loadWithOverviewMode = false
        }
    }

    private fun toggleDesktopMode() {
        desktopMode = !desktopMode
        applyUserAgent()
        desktopButton.text = if (desktopMode) "电脑版：开" else "电脑版：关"
        status.text = "已切换网页模式，正在重新加载当前页面。"
        web.reload()
    }

    private fun openPage() {
        val raw = urlBox.text.toString().trim()
        val url = if (raw.startsWith("https://")) raw else "https://$raw"
        if (!url.startsWith("https://")) {
            status.text = "仅允许 HTTPS 页面。"
            return
        }
        web.loadUrl(url)
    }

    private fun inspectPage() {
        val script = """(function(){
          const clean=s=>(s||'').replace(/\\s+/g,' ').trim();
          const lines=(document.body?document.body.innerText:'').split('\\n').map(clean).filter(Boolean);
          const chapters=lines.filter(x=>/^\\d+(\\.\\d+)?\\s+/.test(x)).slice(0,90);
          const types=lines.filter(x=>/单选题|多选题|判断题|章节测验/.test(x)).slice(0,30);
          const qs=lines.filter(x=>/^\\d+\\s*[［\\[【]?(单选题|多选题|判断题)/.test(x)).slice(0,50);
          return JSON.stringify({title:document.title,chapters:chapters,types:types,questions:qs,
            videoCount:document.querySelectorAll('video').length,hasSubmit:/提交/.test(lines.join(' '))});
        })();"""
        web.evaluateJavascript(script) { raw ->
            val decoded = raw?.replace("\\\"", "\"")?.trim('"') ?: ""
            try {
                val obj = JSONObject(decoded)
                fun section(label: String, arr: JSONArray): String {
                    val b = StringBuilder("$label\n")
                    for (i in 0 until arr.length()) b.append("• ").append(arr.optString(i)).append("\n")
                    return b.toString()
                }
                output.text = "页面：${obj.optString("title")}\n视频元素：${obj.optInt("videoCount")}\n\n" +
                    section("章节线索：", obj.optJSONArray("chapters") ?: JSONArray()) + "\n" +
                    section("题型线索：", obj.optJSONArray("types") ?: JSONArray()) + "\n" +
                    section("题目线索：", obj.optJSONArray("questions") ?: JSONArray()) +
                    "\n提示：用于学习和复习；请自行完成课程测验。"
                status.text = "页面识别完成。动态组件或 iframe 中的内容可能无法提取。"
            } catch (e: Exception) {
                output.text = "暂时无法解析页面结构，请稍后重试或滚动页面后再识别。"
                status.text = "页面识别未成功。"
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::web.isInitialized) {
            web.stopLoading()
            web.destroy()
        }
        super.onDestroy()
    }
}
